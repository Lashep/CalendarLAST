@extends('layouts.app')

@section('content')
<div class="background-image" style="
position: fixed;
bottom: 0;
top: 0;
z-index: -1;
display: block;
background-image: url({{ asset('img/bg.jpg') }});
background-size : cover;
width: 100%;
height: 100vh;
-webkit-filter: blur(10px);
-moz-filter: blur(10px);
-o-filter: blur(10px);
-ms-filter: blur(10px);
filter: blur(10px);"></div>
<div class="container">
    <div class="row" style="
    align-items: center;
    justify-content: center;
    display: flex;
    height: 90vh;">
        <div class="col-md-8 col-md-offset-2" style="padding : 0; margin : 0;">
            <div class="panel panel-default">
                <div class="panel-heading">რეგისტრაცია</div>
                <div class="panel-body" style="padding : 5em 0">
                    <form class="form-horizontal" role="form" method="POST" action="{{ url('/register') }}">
                        {{ csrf_field() }}

                        <div class="form-group{{ $errors->has('name') ? ' has-error' : '' }}" style="margin-bottom : 2.5em">
                            <label for="name" class="col-md-4 control-label">სახელი</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="name" value="{{ old('name') }}" required autofocus>

                                @if ($errors->has('name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}" style="margin-bottom : 2.5em">
                            <label for="email" class="col-md-4 control-label">მეილი</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="{{ old('email') }}" required>

                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}" style="margin-bottom : 2.5em">
                            <label for="password" class="col-md-4 control-label">პაროლი</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password" required>

                                @if ($errors->has('password'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group" style="margin-bottom : 2.5em">
                            <label for="password-confirm" class="col-md-4 control-label">დაადასტურეთ პაროლი</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                            </div>
                        </div>

                        <div class="form-group" style="margin-bottom : 2.5em">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary" style="padding-left : 3em; padding-right : 3em;">
                                    რეგისტრაცია
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
