<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Event extends Model
{
    /**
     * [$table description]
     * @var string
     */
    protected $table = 'events';

    /**
     * [$fillable description]
     * @var [type]
     */
    protected $fillable = [
        'location', 'work', 'title', 'start', 'end', 'color', 'user_id'
    ];
}