<?php $__env->startSection('content'); ?>
<div class="background-image" style="
position: fixed;
bottom: 0;
top: 0;
z-index: -1;
display: block;
background-image: url(<?php echo e(asset('img/bg.jpg')); ?>);
background-size : cover;
width: 100%;
height: 100vh;
-webkit-filter: blur(10px);
-moz-filter: blur(10px);
-o-filter: blur(10px);
-ms-filter: blur(10px);
filter: blur(10px);"></div>
<div class="container">
    <div class="row" style="
    align-items: center;
    justify-content: center;
    display: flex;
    height: 90vh;">
        <div class="col-md-8 col-md-offset-2" style="padding : 0; margin : 0;">
            <div class="panel panel-default">
                <div class="panel-heading">რეგისტრაცია</div>
                <div class="panel-body" style="padding : 5em 0">
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/register')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>" style="margin-bottom : 2.5em">
                            <label for="name" class="col-md-4 control-label">სახელი</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>" style="margin-bottom : 2.5em">
                            <label for="email" class="col-md-4 control-label">მეილი</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>" style="margin-bottom : 2.5em">
                            <label for="password" class="col-md-4 control-label">პაროლი</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group" style="margin-bottom : 2.5em">
                            <label for="password-confirm" class="col-md-4 control-label">დაადასტურეთ პაროლი</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                            </div>
                        </div>

                        <div class="form-group" style="margin-bottom : 2.5em">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary" style="padding-left : 3em; padding-right : 3em;">
                                    რეგისტრაცია
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>