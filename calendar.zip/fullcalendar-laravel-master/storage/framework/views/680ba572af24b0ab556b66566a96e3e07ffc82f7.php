<?php $__env->startSection('content'); ?>
<div class="background-image" style="
position: fixed;
bottom: 0;
top: 0;
z-index: -1;
display: block;
background-image: url(<?php echo e(asset('img/bg.jpg')); ?>);
background-size : cover;
width: 100%;
height: 100vh;
-webkit-filter: blur(10px);
-moz-filter: blur(10px);
-o-filter: blur(10px);
-ms-filter: blur(10px);
filter: blur(10px);"></div>

<div class="container">
    <div class="row" style="
    align-items: center;
    justify-content: center;
    display: flex;
    height: 95vh;">
        <div class="col-md-8 col-md-offset-2" style="padding : 0; margin : 0;">
            <div class="panel panel-default">
                <div class="panel-heading">ავტორიზაცია</div>
                <div class="panel-body" style="padding : 5em 0">
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/login')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>" style="margin-bottom : 2.5em">
                            <label for="email" class="col-md-4 control-label">მეილი</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label for="password" class="col-md-4 control-label">პაროლი</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <div class="checkbox">
                                    <label style="float : right">
                                        <input type="checkbox" name="remember"> დამიმახსოვრე
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary" style="padding-left : 2em; padding-right : 2em;">
                                    შესვლა
                                </button>

                                <a class="btn btn-link" href="<?php echo e(url('/password/reset')); ?>" style="float : right; padding-right : 0;">
                                    დაგავიწყდათ პაროლი?
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>