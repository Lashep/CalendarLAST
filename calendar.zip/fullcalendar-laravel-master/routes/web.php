<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/
Route::group(['middleware' => 'auth'], function () {

    Route::get('/', 'Controller@index');

});
Route::resource('events', 'EventsController',['only' => ['index', 'store', 'update', 'destroy']]);;

Auth::routes();


Route::get('auth/logout', 'Auth\AuthController@logout');

Route::get('/logout', function () {
    Auth::logout();
    return redirect('/login');
});